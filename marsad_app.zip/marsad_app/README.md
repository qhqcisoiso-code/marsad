# تطبيق "الرصد البيئي" - دليل البناء والنشر

تطبيق Flutter احترافي (Android + iOS) لمنصة marsad.gov.iq، مبني كغلاف WebView ذكي
لأن المنصة لا تملك API حالياً. الكود جاهز بالكامل، يبقى عليك خطوات التهيئة والبناء التالية.

## 1. المتطلبات قبل البدء
- تثبيت Flutter SDK (الإصدار 3.x فأعلى): https://docs.flutter.dev/get-started/install
- حساب Firebase (مجاني) لتفعيل الإشعارات: https://console.firebase.google.com
- جهاز Mac (أو خدمة CI سحابية مثل Codemagic/Bitrise) لبناء نسخة iOS — أبل تتطلب ذلك إلزامياً
- حساب Google Play Console (25$ دفعة واحدة) لنشر نسخة أندرويد
- حساب Apple Developer Program (99$ سنوياً) لنشر نسخة iOS

## 2. خطوات الإعداد الأولي

```bash
# فك ضغط المشروع ثم داخل المجلد:
flutter pub get
```

### إضافة الشعار والأيقونة
ضع شعار المنصة الرسمي باسم `logo.png` (مقاس 1024x1024 يفضل) داخل:
```
assets/images/logo.png
```
ثم نفّذ:
```bash
flutter pub run flutter_native_splash:create
flutter pub run flutter_launcher_icons
```
هذا سيولّد تلقائياً شاشة البداية (Splash) وأيقونة التطبيق لكل من أندرويد وآيفون.

### تفعيل الإشعارات (Firebase)
1. أنشئ مشروع جديد على https://console.firebase.google.com
2. أضف تطبيق Android بـ package name: `iq.gov.marsad.app` (أو اسمك المفضل) وحمّل ملف
   `google-services.json` وضعه في `android/app/`
3. أضف تطبيق iOS بنفس الـ Bundle ID وحمّل ملف `GoogleService-Info.plist` وضعه في `ios/Runner/`
4. أضف داخل `android/build.gradle`:
   ```
   classpath 'com.google.gms:google-services:4.4.2'
   ```
   وداخل `android/app/build.gradle` آخر سطر:
   ```
   apply plugin: 'com.google.gms.google-services'
   ```

### إعدادات iOS الإضافية
افتح `ios/Runner/Info.plist` وأضف المفاتيح الموجودة في ملف
`ios_Info_plist_additions.xml` المرفق معك (صلاحيات الكاميرا، الموقع، الإشعارات).

## 3. التعديلات المهمة التي يجب أن تراجعها بنفسك

في `lib/screens/home_webview_screen.dart`:
- راجع روابط التبويبات الأربعة (`_tabs`) وعدّلها لتطابق الروابط الفعلية
  لصفحات "تقديم بلاغ"، "متابعة البلاغات"، "حسابي" في موقعكم.

في `lib/services/location_service.dart`:
- دالة `buildInjectionScript` تحاول تعبئة حقول الإحداثيات تلقائياً بالاعتماد على
  `name="latitude"` و `name="longitude"`. تأكد من تطابق هذه الأسماء مع نموذج
  البلاغ الفعلي في صفحة PHP، أو زوّدني بكود النموذج وأعدّلها لك بدقة.

لتفعيل زر "تحديد موقعي" أو "رفع صورة" من داخل صفحة الويب نفسها (وليس فقط
عناصر HTML العادية)، أضف هذا الكود داخل صفحة PHP الخاصة بالبلاغ:
```html
<button onclick="FlutterLocation.postMessage('get_location')">
  📍 إرفاق موقعي الحالي
</button>
```
هذا الزر سيستدعي تلقائياً تحديد GPS من داخل التطبيق ويملأ الحقول.

## 4. البناء للاختبار

```bash
# تشغيل على المحاكي/الجهاز للاختبار
flutter run

# بناء نسخة أندرويد APK للاختبار السريع
flutter build apk --release

# بناء حزمة App Bundle (المطلوبة فعلياً لرفعها على Google Play)
flutter build appbundle --release

# بناء نسخة iOS (يتطلب macOS + Xcode)
flutter build ios --release
```

## 5. النشر على المتاجر

### Google Play
1. ادخل Google Play Console وأنشئ تطبيق جديد
2. ارفع ملف `build/app/outputs/bundle/release/app-release.aab`
3. عبّئ بيانات التطبيق (الوصف، لقطات الشاشة، سياسة الخصوصية - **مطلوبة لأنها منصة
   تطلب صلاحية الموقع والكاميرا**)
4. أرسل للمراجعة (عادة تستغرق 1-3 أيام لمنصات حكومية)

### App Store
1. افتح المشروع بـ Xcode على جهاز Mac: `open ios/Runner.xcworkspace`
2. اضبط Bundle Identifier، Signing Team، إصدار التطبيق
3. Archive ثم Upload عبر Xcode Organizer لـ App Store Connect
4. عبّئ بيانات التطبيق هناك وأرسل للمراجعة (عادة 1-2 أيام)

⚠️ **ملاحظة مهمة:** أبل أحياناً ترفض تطبيقات الـ WebView الخالصة (بدون قيمة مضافة
حقيقية) بموجب قاعدة 4.2 من إرشاداتهم. الميزات الإضافية التي أضفناها هنا (GPS
الأصلي، الكاميرا، الإشعارات، شريط تنقل native) تقلل من احتمال الرفض بشكل كبير
لأنها تجعل التطبيق "تجربة موبايل حقيقية" وليس مجرد متصفح مصغر.

## 6. هيكل المشروع
```
marsad_app/
├── lib/
│   ├── main.dart                      # نقطة الدخول + تهيئة Firebase
│   ├── screens/
│   │   ├── splash_screen.dart         # شاشة البداية
│   │   └── home_webview_screen.dart   # الشاشة الرئيسية (WebView + كل الميزات)
│   ├── services/
│   │   ├── location_service.dart      # خدمة GPS
│   │   └── notification_service.dart  # خدمة الإشعارات
│   └── widgets/
│       └── no_connection_view.dart    # شاشة انقطاع الإنترنت
├── android/app/src/main/AndroidManifest.xml
├── ios_Info_plist_additions.xml       # أضفها يدوياً لملف Info.plist
└── pubspec.yaml                       # المكتبات المطلوبة
```

## 7. إرسال الإشعارات من سيرفر PHP
بعد تفعيل Firebase، خزّن FCM Token (يُطبع بالـ console عند أول تشغيل) لكل مستخدم
بقاعدة بياناتك، وأرسل الإشعارات عبر Firebase Admin SDK أو REST API مباشرة من PHP:
```php
$url = 'https://fcm.googleapis.com/v1/projects/YOUR_PROJECT_ID/messages:send';
// استخدم Service Account JSON + OAuth token من Firebase Console
```
أخبرني إذا حبيت أجهز لك سكربت PHP كامل لإرسال الإشعارات من لوحة تحكم المنصة.
