import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/foundation.dart';

/// خدمة إدارة الإشعارات - تستقبل تنبيهات من السيرفر
/// (مثل: تنبيهات بيئية عاجلة، تحديث حالة بلاغ، إعلانات من المنصة)
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    // طلب إذن الإشعارات من المستخدم
    await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // إعداد الإشعارات المحلية (لعرضها والتطبيق مفتوح)
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings();
    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );
    await _localNotifications.initialize(initSettings);

    // استقبال الإشعارات والتطبيق بالمقدمة (foreground)
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      _showLocalNotification(message);
    });

    // عند فتح إشعار والتطبيق كان بالخلفية
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint('تم فتح إشعار: ${message.data}');
      // هنا تقدر تضيف منطق التنقل لصفحة معينة حسب بيانات الإشعار
    });

    // الحصول على رمز الجهاز (FCM Token) لإرسال الإشعارات المستهدفة
    final token = await _messaging.getToken();
    debugPrint('FCM Token: $token');
    // أرسل هذا الـ token لسيرفر PHP الخاص بك وخزنه بقاعدة البيانات
    // مرتبط بحساب المستخدم لإرسال إشعارات مخصصة لاحقاً
  }

  void _showLocalNotification(RemoteMessage message) {
    const androidDetails = AndroidNotificationDetails(
      'marsad_channel',
      'إشعارات الرصد البيئي',
      channelDescription: 'تنبيهات وتحديثات منصة الرصد البيئي',
      importance: Importance.high,
      priority: Priority.high,
    );
    const iosDetails = DarwinNotificationDetails();
    const details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    _localNotifications.show(
      message.hashCode,
      message.notification?.title ?? 'الرصد البيئي',
      message.notification?.body ?? '',
      details,
    );
  }
}
