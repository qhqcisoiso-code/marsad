import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

/// خدمة تحديد الموقع الجغرافي - تستخدم عند إرسال بلاغ بيئي
/// تُحقن إحداثيات الموقع داخل صفحة الويب عبر JavaScript
class LocationService {
  LocationService._();
  static final LocationService instance = LocationService._();

  /// طلب صلاحية الموقع من المستخدم، وإرجاع true إذا تم منحها
  Future<bool> requestPermission() async {
    final status = await Permission.location.request();
    return status.isGranted;
  }

  /// التحقق من تفعيل خدمة الموقع على الجهاز (GPS مفعّل أم لا)
  Future<bool> isLocationServiceEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }

  /// الحصول على الموقع الحالي بدقة عالية (lat, lng)
  /// يُستخدم عند ضغط المستخدم على زر "إرفاق موقعي" داخل نموذج البلاغ
  Future<Position?> getCurrentLocation() async {
    final serviceEnabled = await isLocationServiceEnabled();
    if (!serviceEnabled) {
      return null; // اطلب من المستخدم تفعيل GPS من إعدادات الجهاز
    }

    final hasPermission = await requestPermission();
    if (!hasPermission) {
      return null;
    }

    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 15),
      );
    } catch (e) {
      return null;
    }
  }

  /// كود JavaScript يُحقن داخل صفحة الموقع لتعبئة حقول خط الطول/العرض تلقائياً
  /// عدّل أسماء الحقول (lat_field_id, lng_field_id) لتطابق أسماء الـ id الفعلية
  /// في نموذج البلاغ على موقع marsad.gov.iq
  String buildInjectionScript(double lat, double lng) {
    return '''
      (function() {
        var latField = document.querySelector('input[name="latitude"], input#lat');
        var lngField = document.querySelector('input[name="longitude"], input#lng');
        if (latField) { latField.value = "$lat"; latField.dispatchEvent(new Event('input')); }
        if (lngField) { lngField.value = "$lng"; lngField.dispatchEvent(new Event('input')); }
      })();
    ''';
  }
}
