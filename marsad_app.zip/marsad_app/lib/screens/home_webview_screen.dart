import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/location_service.dart';
import '../widgets/no_connection_view.dart';

/// رابط منصة الرصد البيئي الرسمي
const String kBaseUrl = 'https://marsad.gov.iq/';

class HomeWebViewScreen extends StatefulWidget {
  const HomeWebViewScreen({super.key});

  @override
  State<HomeWebViewScreen> createState() => _HomeWebViewScreenState();
}

class _HomeWebViewScreenState extends State<HomeWebViewScreen> {
  late final WebViewController _controller;
  bool _isLoading = true;
  bool _hasError = false;
  bool _isOffline = false;
  double _progress = 0;
  int _currentTabIndex = 0;

  // روابط التبويبات الرئيسية - عدّلها لتطابق صفحات منصتكم الفعلية
  final List<_NavTab> _tabs = const [
    _NavTab('الرئيسية', Icons.home_outlined, kBaseUrl),
    _NavTab('تقديم بلاغ', Icons.report_problem_outlined, '${kBaseUrl}complaint'),
    _NavTab('متابعة البلاغات', Icons.list_alt_outlined, '${kBaseUrl}my-reports'),
    _NavTab('حسابي', Icons.person_outline, '${kBaseUrl}profile'),
  ];

  @override
  void initState() {
    super.initState();
    _checkConnectivity();
    _initWebView();
    Connectivity().onConnectivityChanged.listen((result) {
      final offline = result.contains(ConnectivityResult.none);
      if (mounted) setState(() => _isOffline = offline);
    });
  }

  Future<void> _checkConnectivity() async {
    final result = await Connectivity().checkConnectivity();
    setState(() => _isOffline = result.contains(ConnectivityResult.none));
  }

  void _initWebView() {
    late final PlatformWebViewControllerCreationParams params;
    params = const PlatformWebViewControllerCreationParams();

    _controller = WebViewController.fromPlatformCreationParams(params)
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (progress) {
            setState(() => _progress = progress / 100);
          },
          onPageStarted: (url) {
            setState(() {
              _isLoading = true;
              _hasError = false;
            });
          },
          onPageFinished: (url) {
            setState(() => _isLoading = false);
          },
          onWebResourceError: (error) {
            setState(() {
              _hasError = true;
              _isLoading = false;
            });
          },
          onNavigationRequest: (request) async {
            // فتح الروابط الخارجية (مثل واتساب، اتصال، خرائط) بتطبيقات خارجية بدل الويب فيو
            final uri = Uri.parse(request.url);
            if (!uri.toString().contains('marsad.gov.iq')) {
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
                return NavigationDecision.prevent;
              }
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..addJavaScriptChannel(
        'FlutterCamera',
        onMessageReceived: (message) => _handleImagePick(),
      )
      ..addJavaScriptChannel(
        'FlutterLocation',
        onMessageReceived: (message) => _handleLocationRequest(),
      )
      ..loadRequest(Uri.parse(kBaseUrl));

    if (_controller.platform is AndroidWebViewController) {
      (_controller.platform as AndroidWebViewController)
          .setMediaPlaybackRequiresUserGesture(false);
      (_controller.platform as AndroidWebViewController)
          .setOnShowFileSelector(_androidFilePicker);
    }
  }

  /// دعم رفع الصور من نموذج HTML <input type="file"> على أندرويد
  Future<List<String>> _androidFilePicker(FileSelectorParams params) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.camera, imageQuality: 80);
    if (picked != null) {
      return [Uri.file(picked.path).toString()];
    }
    return [];
  }

  /// عند ضغط المستخدم على زر "رفع صورة البلاغ" المخصص داخل الموقع
  Future<void> _handleImagePick() async {
    final picker = ImagePicker();
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('التقاط صورة'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('اختيار من المعرض'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;
    final image = await picker.pickImage(source: source, imageQuality: 80);
    if (image != null) {
      // يمكن هنا رفع الصورة مباشرة لسيرفر PHP عبر API منفصل لاحقاً إذا توفر
      debugPrint('تم اختيار صورة: ${image.path}');
    }
  }

  /// عند ضغط المستخدم على زر "إرفاق موقعي" داخل نموذج البلاغ في الموقع
  Future<void> _handleLocationRequest() async {
    final loading = _showLoadingDialog('جاري تحديد موقعك...');
    final position = await LocationService.instance.getCurrentLocation();
    if (mounted) Navigator.of(context, rootNavigator: true).pop(); // إغلاق التحميل
    await loading;

    if (position == null) {
      _showSnack('تعذر تحديد الموقع. تأكد من تفعيل GPS ومنح الصلاحية.');
      return;
    }

    final script = LocationService.instance.buildInjectionScript(
      position.latitude,
      position.longitude,
    );
    await _controller.runJavaScript(script);
    _showSnack('تم إرفاق موقعك الحالي بنجاح ✅');
  }

  Future<void> _showLoadingDialog(String message) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        content: Row(
          children: [
            const CircularProgressIndicator(),
            const SizedBox(width: 16),
            Expanded(child: Text(message)),
          ],
        ),
      ),
    );
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<bool> _onWillPop() async {
    if (await _controller.canGoBack()) {
      _controller.goBack();
      return false;
    }
    return true;
  }

  void _onTabTapped(int index) {
    setState(() => _currentTabIndex = index);
    _controller.loadRequest(Uri.parse(_tabs[index].url));
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        final shouldPop = await _onWillPop();
        if (shouldPop && mounted) Navigator.of(context).maybePop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الرصد البيئي'),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: () => _controller.reload(),
            ),
            IconButton(
              icon: const Icon(Icons.share),
              onPressed: () => Share.share(
                'تابع المخالفات البيئية وقدّم بلاغك عبر تطبيق الرصد البيئي: $kBaseUrl',
              ),
            ),
          ],
        ),
        body: _isOffline
            ? NoConnectionView(onRetry: () {
                _checkConnectivity();
                _controller.reload();
              })
            : Stack(
                children: [
                  RefreshIndicator(
                    onRefresh: () async => _controller.reload(),
                    child: WebViewWidget(controller: _controller),
                  ),
                  if (_isLoading)
                    LinearProgressIndicator(
                      value: _progress,
                      backgroundColor: Colors.transparent,
                      color: const Color(0xFF1B5E20),
                    ),
                  if (_hasError)
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.error_outline, size: 60, color: Colors.grey),
                          const SizedBox(height: 12),
                          const Text('حدث خطأ أثناء تحميل الصفحة'),
                          const SizedBox(height: 12),
                          ElevatedButton(
                            onPressed: () => _controller.reload(),
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentTabIndex,
          onTap: _onTabTapped,
          selectedItemColor: const Color(0xFF1B5E20),
          type: BottomNavigationBarType.fixed,
          items: _tabs
              .map((t) => BottomNavigationBarItem(icon: Icon(t.icon), label: t.label))
              .toList(),
        ),
      ),
    );
  }
}

class _NavTab {
  final String label;
  final IconData icon;
  final String url;
  const _NavTab(this.label, this.icon, this.url);
}
