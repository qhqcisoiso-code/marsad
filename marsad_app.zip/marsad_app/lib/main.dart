import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/splash_screen.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // تهيئة Firebase للإشعارات (Push Notifications)
  // ملاحظة: لازم تضيف ملف google-services.json (أندرويد) و GoogleService-Info.plist (آيفون)
  // من مشروعك على Firebase Console قبل البناء
  try {
    await Firebase.initializeApp();
    await NotificationService.instance.initialize();
  } catch (e) {
    debugPrint('Firebase init skipped/failed: $e');
  }

  runApp(const MarsadApp());
}

class MarsadApp extends StatelessWidget {
  const MarsadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'الرصد البيئي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', 'IQ'),
      theme: ThemeData(
        primaryColor: const Color(0xFF1B5E20), // أخضر بيئي - عدّله حسب هوية المنصة
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B5E20),
          primary: const Color(0xFF1B5E20),
        ),
        fontFamily: 'Cairo',
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1B5E20),
          foregroundColor: Colors.white,
          elevation: 2,
          centerTitle: true,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
